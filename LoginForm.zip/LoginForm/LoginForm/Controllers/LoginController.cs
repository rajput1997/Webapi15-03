﻿using LoginForm.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using LoginForm.Utility;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LoginForm.Controllers
{
    public class LoginController : Controller
    {
        private readonly LoginDbContext _auc;       
        public LoginController(LoginDbContext auc)
        {
            _auc = auc;
        }
        [HttpGet]
        public IActionResult Index()
        {
            var logn = _auc.UserRegistration.ToList();            
            return View(logn);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Details(int Id)
        {
            var logn = _auc.UserRegistration.Where(e => e.UserId == Id).FirstOrDefault();
            return View(logn);
        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            var logn = _auc.UserRegistration.Where(e => e.UserId == Id).FirstOrDefault();            
            return View(logn);
        }
        [HttpGet]
        public IActionResult Delete(int Id)
        {
            var logn = _auc.UserRegistration.Where(e => e.UserId == Id).FirstOrDefault();
            return View(logn);
        }
        [HttpPost]
        public IActionResult Create(Login lo)
        {
            lo.Pwd = EncDecPassword.MD5Hash(lo.Pwd.ToString());
            _auc.UserRegistration.Add(lo);
            _auc.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Edit(Login lo)
        {
            _auc.UserRegistration.Update(lo);
            _auc.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Delete(Login lo)
        {
            _auc.UserRegistration.Remove(lo);
            _auc.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View("Login");
        }
        [HttpPost]
        public IActionResult Login(Login lo)
        {
            var userlist = _auc.UserRegistration.ToList();
            lo.Pwd = EncDecPassword.MD5Hash(lo.Pwd);
            var value = _auc.UserRegistration.Where(a => a.Pwd == lo.Pwd && a.Username == lo.Username).SingleOrDefault();
            if (value != null)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return View ("Create");
            }
        }
    }
}
  
